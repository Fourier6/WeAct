#ifndef IMAGE_H
#define IMAGE_H
#include "main.h"
uint8_t OSTU(uint16_t* img);
uint8_t adapt_threshold(uint16_t* img);
void gray_img1(uint32_t date1,uint32_t date2,uint32_t date3);
#endif
